#!/bin/bash

apt update
apt-get install -y build-essential tcl8.5 tcl8.5-dev gawk gzip bzip2 p7zip libboost-all-dev unzip git cmake nano 

tar -xvf gizapp.tar.gz
cd giza-pp
make clean

cd ..
unzip mosesdecoder-RELEASE-0.91.zip
mkdir srilm && tar -xvzf srilm.tgz -C ./srilm
cd srilm
export SRILM=`pwd`
cd ..
cp ./settings/Makefile ./srilm/
cp ./settings/machine-type ./srilm/sbin/
cd srilm
make World
cd ..
#python make_srilm_m64.py
#cd srilm
#make World
cd mosesdecoder-RELEASE-0.91
./bjam --with-srilm=$SRILM -j1
cd ..
cd giza-pp
make clean
make

cd ..

git clone https://github.com/moses-smt/mgiza.git
cd mgiza
cd mgizapp
cmake .
make

cp scripts/*.py /usr/local/bin
cp bin/mgiza /usr/local/bin

cd ../../

./install.sh
