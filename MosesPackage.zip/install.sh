cp giza-pp/GIZA++-v2/GIZA++ /usr/local/bin
cp giza-pp/GIZA++-v2/snt*.out /usr/local/bin
cp giza-pp/mkcls-v2/mkcls /usr/local/bin
cp -r mosesdecoder-RELEASE-0.91/scripts/generic/ /usr/local/bin
cp -r mosesdecoder-RELEASE-0.91/scripts/training/* /usr/local/bin
cp -r mosesdecoder-RELEASE-0.91/scripts/training/ /usr/local/bin
cp mosesdecoder-RELEASE-0.91/bin/* /usr/local/bin
cp srilm/bin/i686-m64/* /usr/local/bin
chmod 755 -R /usr/local/bin

