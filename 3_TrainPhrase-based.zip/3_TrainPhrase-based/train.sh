#!/bin/bash
clean-corpus-n.perl ./corpus/lang src trg ./corpus/clean 1 40
ngram-count -text ./corpus/clean.trg -lm ./corpus/clean.trg.lm
train-model.perl -external-bin-dir /usr/local/bin --root-dir . -corpus `pwd`/corpus/clean -f src -e trg \
 -alignment grow-diag-final-and -reordering msd-bidirectional-fe -lm 0:3:`pwd`/corpus/clean.trg.lm \
 -mgiza -mgiza-cpus 8
