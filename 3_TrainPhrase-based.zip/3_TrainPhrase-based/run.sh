#!/bin/bash
moses -f ./model/moses.ini
