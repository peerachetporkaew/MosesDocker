#!/bin/bash
rm -rf g*
cp ./corpus/lang.src .
cp ./corpus/lang.trg .
rm -f corpus/*
rm -rf m*
mv ./lang.src ./corpus/lang.src
mv ./lang.trg ./corpus/lang.trg
